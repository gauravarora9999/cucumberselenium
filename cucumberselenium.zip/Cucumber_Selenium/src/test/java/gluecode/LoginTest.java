package gluecode;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import constants.AppConstants;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import elementlocators.ElementLocators;

public class LoginTest {

	public static WebDriver driver;

	@Given("^loginPage$")
	public void loginpage() throws Throwable {

		System.setProperty("webdriver.chrome.driver", AppConstants.chromeDriverLocation);
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); // This is the default timeout
		driver.get(AppConstants.loginUrl);
		driver.manage().window().maximize();
	}

	@When("^user enters username and password$")
	public void user_enters_username_and_password() throws Throwable {
		driver.findElement(By.id(ElementLocators.emailTextFieldLocator)).sendKeys(AppConstants.email);
		driver.findElement(By.id(ElementLocators.pwdTextFieldLocator)).sendKeys(AppConstants.pwd);
		driver.findElement(By.id(ElementLocators.loginButtonLocator)).click();
	}

	@Then("^validate login is successful$")
	public void validate_login_is_successful() throws Throwable {
		if (driver.findElement(By.linkText(ElementLocators.homeLinkLocator)) != null) {
			System.out.println("------Login is Successfull!!------");
		}
	}

	@Then("^navigate to services page$")
	public void navigate_to_services_page() throws Throwable {

		driver.findElement(By.xpath(ElementLocators.servicesLinkLocator)).click();
		driver.findElement(By.xpath(ElementLocators.myServiceLinkLocator)).click();
		Thread.sleep(3000);
	}

	@Then("^user successfully logout$")
	public void user_successfully_logout() throws Throwable {
		driver.findElement(By.xpath("//*[@id='Secondary_Navbar-Account']/a")).click();
		driver.findElement(By.xpath("//*[@id='Secondary_Navbar-Account-Logout']/a")).click();
		if (driver.getPageSource().contains(ElementLocators.logoutText)) {
			System.out.println("-----Logout is successful!!---------");
		}

		Thread.sleep(2000);
		System.out.println("-------Closing Browser----------");
		driver.close();
		driver.quit();

		System.out.println("--------Test Done!!-------------");
	}
}
