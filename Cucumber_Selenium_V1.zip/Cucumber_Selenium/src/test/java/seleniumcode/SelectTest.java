package seleniumcode;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import constants.AppConstants;

public class SelectTest {

	public static void captureScreenMethod() throws Exception {
		System.setProperty("webdriver.chrome.driver", AppConstants.chromeDriverLocation);
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get("https://www.softwaretestingmaterial.com/sample-webpage-to-automate/");
		driver.manage().window().maximize();
		driver.navigate().refresh();
		Thread.sleep(10000);
		WebElement mySelectElement = driver.findElement(By.name("dropdown"));
		Select dropdown = new Select(mySelectElement);
		dropdown.selectByVisibleText("Automation Testing");
		//dropdown.selectByIndex(2);

		mySelectElement = driver.findElement(By.name("multipleselect[]"));
		dropdown = new Select(mySelectElement);
		
		dropdown.selectByVisibleText("Performance Testing");
		Thread.sleep(4000);
		dropdown.deselectByVisibleText("Performance Testing");
	}

	public static void main(String args[]) throws Exception {
		captureScreenMethod();
	}
}