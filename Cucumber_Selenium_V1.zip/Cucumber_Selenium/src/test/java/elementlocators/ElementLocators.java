package elementlocators;

public class ElementLocators {
	
	public static final String loginButtonLocator = "login";
	public static final String emailTextFieldLocator = "inputEmail";
	public static final String pwdTextFieldLocator = "inputPassword";
	public static final String homeLinkLocator = "Home";
	public static final String servicesLinkLocator = "//*[@id='Primary_Navbar-Services']/a";
	public static final String myServiceLinkLocator = "//*[@id='Primary_Navbar-Services-My_Services']/a";
	public static final String logoutText = "You have been successfully logged out.";

}
